const char* ssid     = "wifiduino";
const char* password = "cifpenadeje2025";
const char* hostname = "ESP8266_mqtt_1";

IPAddress ip(192, 168, 10, 35);
IPAddress gateway(192, 168, 10, 1);
IPAddress subnet(255, 255, 255, 0);
