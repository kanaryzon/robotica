
bool cuentaMilisegundos(int periodo, long &tiempoAhora)
{
  if(millis() >= tiempoAhora + periodo){
    tiempoAhora = millis();
    //Serial.println("Hola");
  return (true);
  }else
  {
    return (false);
  }
}